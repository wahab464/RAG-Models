import os
from dotenv import load_dotenv
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough

load_dotenv()

def resume_chatbot(file_path, query):
    # 1) Load resume
    if file_path.endswith(".pdf"):
        loader = PyPDFLoader(file_path)
    else:
        loader = Docx2txtLoader(file_path)
    documents = loader.load()

    # 2) Split into chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_documents(documents)

    # 3) Embeddings + store in Chroma
    embedding = OpenAIEmbeddings()
    vectordb = Chroma.from_documents(chunks, embedding)
    retriever = vectordb.as_retriever(search_kwargs={"k": 3})

    # 4) Define LLM
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)

    # 5) Prompt template
    template = """You are an assistant that answers based only on the candidate's resume.

Context:
{context}

Question:
{question}

Answer:"""
    prompt = ChatPromptTemplate.from_template(template)

    # 6) LCEL Chain
    chain = (
        {"context": retriever, "question": RunnablePassthrough()}| prompt| llm
    )

    # 7) Run chain
    result = chain.invoke(query)
    return result.content

if __name__ == "__main__":
    answer = resume_chatbot(
        r"C:\Users\Lenovo\Downloads\Muhammad Abdul Wahab Resume.pdf",
        "What programming skills does this candidate have?"
    )
    print("Answer:", answer)
