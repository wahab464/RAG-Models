import os
from dotenv import load_dotenv
from PIL import Image
from transformers import VisionEncoderDecoderModel, ViTImageProcessor, AutoTokenizer
from langchain.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain.schema.runnable import RunnablePassthrough

load_dotenv()

# STEP 2: Image Captioning Model
cap_model = VisionEncoderDecoderModel.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
cap_processor = ViTImageProcessor.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
cap_tokenizer = AutoTokenizer.from_pretrained("nlpconnect/vit-gpt2-image-captioning")

def get_caption(image_path):
    """Generate caption from food image"""
    image = Image.open(image_path).convert("RGB")
    inputs = cap_processor(images=image, return_tensors="pt").pixel_values
    ids = cap_model.generate(inputs, max_length=64, num_beams=4)
    return cap_tokenizer.decode(ids[0], skip_special_tokens=True)

# STEP 3: OpenAI LLM
llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)

# STEP 4: Prompt Template
prompt = ChatPromptTemplate.from_template("""
You are a chef AI.Based on this food description: "{caption}",write a simple recipe including:

- Title
- Ingredients (bulleted)
- Steps (numbered, short, clear)
""")

# STEP 5: LCEL Chain
chain = (
    {"caption": RunnablePassthrough()}| prompt| llm
)

# STEP 6: Run the Pipeline
if __name__ == "__main__":

    caption = get_caption(r"C:\Users\Lenovo\Downloads\images.jpg")
    print("Caption:", caption)

    recipe = chain.invoke(caption)
    print("\n Recipe:\n", recipe.content)
