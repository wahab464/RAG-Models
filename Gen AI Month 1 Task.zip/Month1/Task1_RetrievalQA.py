import os
from dotenv import load_dotenv
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.chains import RetrievalQA

load_dotenv()

def resume_chatbot(file_path, query):
    # 1) Load resume
    if file_path.endswith(".pdf"):
        loader = PyPDFLoader(file_path)
    else:
        loader = Docx2txtLoader(file_path)
    documents = loader.load()

    # 2) Split into chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_documents(documents)

    # 3) Embeddings + store in Chroma
    embedding = OpenAIEmbeddings()
    vectordb = Chroma.from_documents(chunks, embedding)

    # 4) Retriever + OpenAI LLM
    retriever = vectordb.as_retriever(search_kwargs={"k": 3}) #k=3 fetch 3 most relevant chunks for each query
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)

    # 5) RetrievalQA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        return_source_documents=False
    )

    # 6) Run query
    result = qa_chain.invoke(query)
    return result["result"]

if __name__ == "__main__":

    answer = resume_chatbot( r"C:\Users\Lenovo\Downloads\Muhammad Abdul Wahab CV.pdf",
        "What programming skills does this candidate have?"
    )
    print("Answer:", answer)
