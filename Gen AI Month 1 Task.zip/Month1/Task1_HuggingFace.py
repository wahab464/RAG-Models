from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, pipeline
from langchain_huggingface import HuggingFacePipeline

def resume_chatbot(file_path, query):
    # 1) Load resume
    if file_path.endswith(".pdf"):
        loader = PyPDFLoader(file_path)
    else:
        loader = Docx2txtLoader(file_path)
    documents = loader.load()

    # 2) Split into chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_documents(documents)

    # 3) Embeddings (lighter model)
    embedding = HuggingFaceEmbeddings(model_name="sentence-transformers/paraphrase-MiniLM-L3-v2")
    vectordb = Chroma.from_documents(chunks, embedding)
    retriever = vectordb.as_retriever(search_kwargs={"k": 3})

    # 4) Load lightweight Hugging Face model (FLAN-T5-small)
    model_name = "google/flan-t5-small"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    pipe = pipeline("text2text-generation", model=model, tokenizer=tokenizer, max_length=256)
    llm = HuggingFacePipeline(pipeline=pipe)

    # 5) Prompt template (concise output)
    template = """You are an assistant that answers strictly based on the candidate's resume.

Context:
{context}

Question:
{question}

Answer format:
- Provide only the main content.
- Keep it short and concise.
- For skills, return only a clean comma-separated list.
"""
    prompt = ChatPromptTemplate.from_template(template)

    # 6) LCEL Chain
    chain = (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | llm
    )

    # 7) Run query
    result = chain.invoke(query)
    return result

if __name__ == "__main__":
    answer = resume_chatbot(
        r"C:\Users\Lenovo\Downloads\Muhammad Abdul Wahab CV.pdf",
        "What programming skills does this candidate have?"
    )
    print("Answer:", answer)
