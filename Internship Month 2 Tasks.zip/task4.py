import os
from dotenv import load_dotenv
import gradio as gr
from openai import OpenAI

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

PERSONALITIES = {
    "Professional": "You are a professional assistant. Respond formally and concisely.",
    "Casual": "You are a friendly assistant. Use casual, relaxed language.",
    "Funny": "You are a humorous assistant. Make your responses funny and witty."
}

def chat(user_input, personality):
    personality_prompt = PERSONALITIES.get(personality, PERSONALITIES["Professional"])
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": personality_prompt},
            {"role": "user", "content": user_input}
        ],
        temperature=0.7
    )
    
    return response.choices[0].message.content.strip()

with gr.Blocks() as demo:
    gr.Markdown("## 🌟 Multi-Personality Chatbot")
    
    with gr.Row():
        user_input = gr.Textbox(label="Your Message", placeholder="Type your message here...")
        personality = gr.Dropdown(
            choices=["Professional", "Casual", "Funny"], 
            value="Professional", 
            label="Choose Personality"
        )
    
    chat_output = gr.Textbox(label="Bot Reply")
    
    user_input.submit(chat, inputs=[user_input, personality], outputs=chat_output)
    gr.Button("Send").click(chat, inputs=[user_input, personality], outputs=chat_output)

demo.launch()
