import os
from dotenv import load_dotenv
import openai
import random

load_dotenv()

from openai import OpenAI
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_synthetic_stock(symbol):
    price = round(random.uniform(100, 500), 2)
    trend = random.choice(["up", "down", "unchanged"])
    return {"price": price, "trend": trend}

def generate_synthetic_headline(symbol, trend):
    prompt = f"""
    You are a financial analyst. Generate a professional financial headline and a 2-3 sentence summary for {symbol}.
    The stock trend today is {trend}.
    Also, provide a short synthetic prediction for tomorrow's trend (up, down, or unchanged).
    """
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role":"user","content":prompt}],
        temperature=0.7,
        max_tokens=200
    )
    return response.choices[0].message.content.strip()

def stock_chat(user_input):
    words = user_input.split()
    for word in words:
        if word.startswith("$"):
            symbol = word.upper().replace("$","")
            stock = get_synthetic_stock(symbol)
            headline = generate_synthetic_headline(symbol, stock['trend'])
            
            reply = f"Current synthetic price of {symbol}: ${stock['price']:.2f} ({stock['trend']})\n"
            reply += f"\n{headline}"
            return reply
    
    return "Please provide a stock symbol prefixed with $, e.g., $AAPL"

if __name__ == "__main__":
    print("Welcome to Synthetic Stock Market Chatbot!")
    print("Type your query (use $SYMBOL), or 'exit' to quit.\n")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        reply = stock_chat(user_input)
        print(f"\nBot:\n{reply}\n")
